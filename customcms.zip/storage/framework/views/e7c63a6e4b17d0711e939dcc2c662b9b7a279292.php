<!-- Footer -->
<footer class="mt-auto">
    <div class="footer">
        <span class='uppercase'>&copy; 2022 Yeti Themes</span>
        <nav>
            <a href="mailto:Yeti Themes<info@yetithemes.net>?subject=Support">Support</a>
            <span class="divider">|</span>
            <a href="http://yeti.yetithemes.net/docs" target="_blank" rel="noreferrer">Docs</a>
        </nav>
    </div>
</footer><?php /**PATH E:\xampp\htdocs\customcms\resources\views/partials/_footer.blade.php ENDPATH**/ ?>