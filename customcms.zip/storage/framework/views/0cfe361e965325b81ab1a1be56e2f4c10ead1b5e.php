

<?php $__env->startSection('workspace'); ?>

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <h1>Tables</h1>
        <ul>
            <li><a href="#no-link">Tag</a></li>
            <li class="divider la la-arrow-right"></li>
            <li><a href="#no-link">List</a></li>
        </ul>
    </section>

    <div class="grid gap-5">
        <!-- Striped -->
        <div class="flex flex-col gap-y-5">
            <div class="card p-5">
            <a class="btn btn_primary float-end" href="<?php echo e(route('tag.create')); ?>"> Add Tag</a>
                <table class="table table_striped w-full mt-3">
                    <thead>
                        <tr>
                            <th class="ltr:text-left rtl:text-right uppercase">#</th>
                            <th class="ltr:text-left rtl:text-right uppercase">Tag</th>
                            <th class="ltr:text-left rtl:text-right uppercase">Status</th>
                            <th class="ltr:text-left rtl:text-right uppercase">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>1</td>
                            <td><?php echo e($tag->tag); ?></td>
                            <td><?php echo !!$tag->status ? '<span class="badge bg-success">Active</span>': '<span
                                                class="badge bg-danger">Inactive</span>'; ?></td>
                            <td>
                            <a class="btn btn_primary" href="<?php echo e(route('tag.edit',$tag->id)); ?>">Edit</a>
                                <form class="d-inline" method="POST" action="<?php echo e(route('tag.destroy', $tag->id)); ?>">

                                    <?php echo method_field('delete'); ?>

                                    <?php echo csrf_field(); ?>

                                    <button class="btn btn_danger" type="submit">Delete</button>

                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Striped End -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Chat - Applications', 'footer' => false, 'workspaceClasses' => 'pb-32'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\customcms\resources\views/tag/index.blade.php ENDPATH**/ ?>