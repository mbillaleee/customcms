<?php echo $__env->make('partials._header', ['title' => $title ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <?php echo $__env->make('partials._navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Workspace -->
    <main class="workspace <?php if (! empty(trim($__env->yieldContent('sidebar')))): ?> workspace_with-sidebar <?php endif; ?> <?php echo e($workspaceClasses ?? ''); ?>">

        <?php echo $__env->yieldContent('workspace'); ?>

        <?php if(!isset($footer) or $footer): ?>
            <?php echo $__env->make('partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </main>

    <?php if (! empty(trim($__env->yieldContent('sidebar')))): ?>

        <!-- Sidebar -->
        <aside class="sidebar">

            <!-- Toggler - Mobile -->
            <button class="sidebar-toggler la la-ellipsis-v" data-toggle="sidebar"></button>

            <?php echo $__env->yieldContent('sidebar'); ?>

        </aside>

    <?php endif; ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('build/js/vendor.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('build/js/script.js')); ?>"></script>

</body>

</html>
<?php /**PATH E:\xampp\htdocs\customcms\resources\views/layouts/master.blade.php ENDPATH**/ ?>